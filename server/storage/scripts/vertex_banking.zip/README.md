# Vertex Banking v1.2.0
Premium resource by Vertex Studio.
