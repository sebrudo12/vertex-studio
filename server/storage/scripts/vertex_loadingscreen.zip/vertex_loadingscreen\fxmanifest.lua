fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Vertex Studio'
description 'Vertex Studio - Cyber-Chrome Loading Screen (Standalone / All Frameworks)'
version '1.0.0'

-- Cargar interfaz NUI en la pantalla de carga de FiveM
loadscreen 'html/index.html'
loadscreen_cursor 'yes'

-- Archivos accesibles por el cliente
files {
    'html/index.html',
    'html/css/**',
    'html/js/**',
    'html/assets/**',
    'html/*.mp3',
    'html/*.mp4'
}
