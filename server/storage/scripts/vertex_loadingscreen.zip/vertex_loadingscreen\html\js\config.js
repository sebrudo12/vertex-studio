/**
 * ==============================================================================
 * VERTEX STUDIO - PANTALLA DE CARGA (LOADING SCREEN) PARA FIVEM
 * ==============================================================================
 * Inspirado en las mejores características de Tuff Loading, Wasabi y UM-Ronin.
 * Compatible con TODOS los frameworks (ESX, QBCore, Qbox, Standalone).
 * Todos los derechos reservados a Vertex Studio.
 * ==============================================================================
 */

const Config = {
    // --------------------------------------------------------------------------
    // IDENTIDAD Y MARCA (BRANDING)
    // --------------------------------------------------------------------------
    studio: {
        name: "VERTEX STUDIO",
        tagline: "NEXT-GEN SCRIPTS & FIVEM SOLUTIONS",
        subtext: "Innovación, Optimización y Experiencias de Rol Únicas",
        logo: "assets/logo.png",
        serverBadge: "v2.5 PERFORMANCE READY",
        promoBanner: "🔥 CÓDIGO 'VERTEX2026' - 20% DE DESCUENTO EN TEBEX",
        announcement: "🔥 Nueva temporada: Nuevos scripts exclusivos ya disponibles en nuestra tienda oficial."
    },

    // --------------------------------------------------------------------------
    // AJUSTES DE AUDIO (LOCAL MUSIC.MP3)
    // --------------------------------------------------------------------------
    audio: {
        autoplay: true,           // Reproducir automáticamente al entrar
        defaultVolume: 25,        // Volumen inicial (0 a 100)
        file: "assets/music.mp3", // Archivo de música local (coloca tu music.mp3 en html/assets/ o html/)
        title: "music.mp3",       // Nombre de la canción en el reproductor
        artist: "Vertex Studio"   // Autor / Artista
    },

    // --------------------------------------------------------------------------
    // REDES SOCIALES Y ENLACES OFICIALES
    // --------------------------------------------------------------------------
    socials: [
        {
            id: "discord",
            name: "Discord",
            icon: "fab fa-discord",
            url: "https://discord.gg/vertexstudio",
            copyOnClick: true,
            handle: "discord.gg/vertexstudio",
            guildId: "vertexstudio",
            fallbackOnline: "1,420"
        },
        {
            id: "tebex",
            name: "Tienda Oficial",
            icon: "fas fa-shopping-cart",
            url: "https://vertexstudio.tebex.io",
            copyOnClick: false,
            handle: "vertexstudio.tebex.io"
        },
        {
            id: "youtube",
            name: "YouTube",
            icon: "fab fa-youtube",
            url: "https://youtube.com/@vertexstudio",
            copyOnClick: false,
            handle: "@vertexstudio"
        }
    ],

    // --------------------------------------------------------------------------
    // TIPS / CONSEJOS ROTATIVOS (Se muestran mientras el jugador descarga recursos)
    // --------------------------------------------------------------------------
    tips: [
        {
            category: "OPTIMIZACIÓN",
            text: "Todos los scripts de Vertex Studio cuentan con un consumo inferior a 0.01ms en idle.",
            icon: "fas fa-microchip"
        },
        {
            category: "COMUNIDAD",
            text: "Únete a nuestro Discord para recibir soporte técnico directo 24/7 y actualizaciones gratuitas.",
            icon: "fab fa-discord"
        },
        {
            category: "MODULARIDAD",
            text: "Compatible al 100% con ESX Legacy, QBCore Framework, Qbox y sistemas Standalone.",
            icon: "fas fa-layer-group"
        },
        {
            category: "SEGURIDAD",
            text: "Protección integral contra exploits e inyecciones en todos nuestros endpoints y callbacks.",
            icon: "fas fa-shield-alt"
        },
        {
            category: "TIENDA TEBEX",
            text: "Aprovecha descuentos exclusivos de lanzamiento con el código promocional VERTEX2026.",
            icon: "fas fa-tag"
        }
    ],
    tipsInterval: 6000,

    // --------------------------------------------------------------------------
    // NOVEDADES / CHANGELOG (UPDATES)
    // --------------------------------------------------------------------------
    updates: [
        {
            version: "v2.5.0",
            date: "Septiembre 2026",
            badge: "ACTUAL",
            title: "Actualización Mayor del Ecosistema",
            items: [
                "Migración completa de callbacks a lib.callback (ox_lib) para máxima velocidad.",
                "Nuevo sistema de sincronización de estados para servidores con más de 128 slots.",
                "Rediseño visual de todas las interfaces NUI con soporte para monitores 4K."
            ]
        },
        {
            version: "v2.4.2",
            date: "Agosto 2026",
            badge: "ESTABLE",
            title: "Parche de Estabilidad y Seguridad",
            items: [
                "Añadido sistema de rate-limit en llamadas a base de datos.",
                "Corrección en la detección de resolución ultrawide 21:9.",
                "Optimización de texturas e iconos en el paquete web."
            ]
        },
        {
            version: "v2.3.0",
            date: "Julio 2026",
            badge: "LEGACY",
            title: "Lanzamiento de la Suite Modular",
            items: [
                "Integración universal para Qbox y QBCore 2.0.",
                "Añadido sistema de traducción automática multilingüe (ES/EN/FR/DE)."
            ]
        }
    ],

    // --------------------------------------------------------------------------
    // REGLAS / NORMATIVA O TÉRMINOS
    // --------------------------------------------------------------------------
    rules: [
        {
            category: "LICENCIAS Y SOPORTE",
            items: [
                {
                    title: "Protección de Propiedad Intelectual",
                    desc: "Todos los scripts cuentan con sistema de cifrado oficial Tebex Asset Escrow. Queda prohibida su reventa o filtración."
                },
                {
                    title: "Soporte Oficial y Actualizaciones",
                    desc: "El soporte técnico se brinda exclusivamente mediante tickets en nuestro Discord oficial para clientes verificados."
                }
            ]
        },
        {
            category: "ESTÁNDARES DE DESARROLLO",
            items: [
                {
                    title: "Rendimiento y Optimización",
                    desc: "Garantizamos un uso óptimo del hilo principal de CPU con cero fugas de memoria (memory leaks)."
                },
                {
                    title: "Compatibilidad Multi-Framework",
                    desc: "Estructura modular compatible de forma nativa con ESX Legacy, QBCore, Qbox y scripts Ox."
                }
            ]
        }
    ],

    // --------------------------------------------------------------------------
    // EQUIPO / STAFF DE VERTEX STUDIO
    // --------------------------------------------------------------------------
    staff: [
        {
            name: "Vertex Prime",
            role: "Lead Developer & Founder",
            avatar: "assets/logo.png",
            discord: "vertex_lead",
            badge: "FOUNDER",
            description: "Especialista en Lua 5.4, Backend C# y arquitectura de alto rendimiento."
        },
        {
            name: "Nexus Design",
            role: "UI/UX & NUI Specialist",
            avatar: "assets/logo.png",
            discord: "nexus_ui",
            badge: "DEVELOPER",
            description: "Diseñador de interfaces futuristas, animaciones fluidas y WebGL."
        },
        {
            name: "Aegis Security",
            role: "QA & Support Manager",
            avatar: "assets/logo.png",
            discord: "aegis_qa",
            badge: "SUPPORT",
            description: "Auditoría de código, control de calidad y asistencia 24/7 a la comunidad."
        }
    ],

    // --------------------------------------------------------------------------
    // CONTROLES / GUÍA DE TECLAS (KEYBINDS)
    // --------------------------------------------------------------------------
    keybinds: [
        { key: "ESPACIO", action: "Pausar / Reanudar Música", desc: "Controla la reproducción de audio en la pantalla de carga" },
        { key: "M", action: "Silenciar Audio (Mute)", desc: "Apaga o enciende el sonido al instante" },
        { key: "H", action: "Modo Cine (Ocultar Interfaz)", desc: "Oculta o muestra la interfaz para disfrutar del video de fondo" },
        { key: "J", action: "Minijuegos de Espera", desc: "Abre la suite de 3 minijuegos interactivos" },
        { key: "F1", action: "Menú Principal", desc: "Abre el menú interactivo del jugador en el servidor" },
        { key: "F2", action: "Inventario", desc: "Abre tu inventario con ranuras de acceso rápido" },
        { key: "K", action: "Menú de Vehículo", desc: "Control de motor, luces, puertas y limitador" },
        { key: "Z", action: "Rango de Voz", desc: "Alterna el alcance de tu voz (Susurro, Normal, Grito)" }
    ],

    // --------------------------------------------------------------------------
    // SISTEMA MULTILENGUAJE (ESPAÑOL / ENGLISH)
    // --------------------------------------------------------------------------
    translations: {
        es: {
            nav: {
                home: "Inicio",
                updates: "Novedades",
                rules: "Normativa",
                staff: "Equipo",
                keybinds: "Teclas"
            },
            tools: {
                minigame: "Minijuegos",
                cinema: "Cine",
                performance: "Eco GPU"
            },
            cinema: {
                active: "Modo Cine Activado (Presiona [H] o haz clic para salir)",
                hint: "Presiona [H] o haz clic para salir del Modo Cine"
            },
            performance: {
                enabled: "Modo Rendimiento Activado: Video pausado para máximo ahorro de GPU",
                disabled: "Modo Rendimiento Desactivado: Video reanudado"
            },
            discord: {
                online: "En línea"
            },
            status: {
                connecting: "Conectando al servidor...",
                ready: "¡Carga finalizada! Entrando a la sesión..."
            },
            minigame: {
                title: "VERTEX ARCADE SUITE",
                subtitle: "Minijuegos integrados mientras se descargan los recursos",
                spaceTitle: "Space Defender",
                snakeTitle: "Neon Snake",
                hackTitle: "Memory Hack",
                spaceDesc: "Defiende el núcleo destruyendo cristales espaciales",
                snakeDesc: "Come diamantes de datos y evita chocar",
                hackDesc: "Memoriza y reproduce la secuencia de bloques",
                score: "PUNTOS",
                highScore: "RÉCORD",
                lives: "VIDAS",
                startPrompt: "PRESIONA [ESPACIO] PARA COMENZAR",
                gameOver: "¡FIN DE LA PARTIDA!",
                restartPrompt: "PRESIONA [ESPACIO] PARA REINICIAR",
                controlsHelp: "Controles: Flechas o [A][D] para mover | [ESPACIO] para disparar"
            }
        },
        en: {
            nav: {
                home: "Home",
                updates: "Updates",
                rules: "Rules",
                staff: "Staff",
                keybinds: "Keybinds"
            },
            tools: {
                minigame: "Minigames",
                cinema: "Cinema",
                performance: "Eco GPU"
            },
            cinema: {
                active: "Cinema Mode Active (Press [H] or click to exit)",
                hint: "Press [H] or click to exit Cinema Mode"
            },
            performance: {
                enabled: "Performance Mode Active: Video paused for GPU savings",
                disabled: "Performance Mode Disabled: Video resumed"
            },
            discord: {
                online: "Online"
            },
            status: {
                connecting: "Connecting to server...",
                ready: "Loading complete! Joining session..."
            },
            minigame: {
                title: "VERTEX ARCADE SUITE",
                subtitle: "Integrated minigames while loading server resources",
                spaceTitle: "Space Defender",
                snakeTitle: "Neon Snake",
                hackTitle: "Memory Hack",
                spaceDesc: "Defend the core by destroying space crystals",
                snakeDesc: "Collect data diamonds and avoid walls",
                hackDesc: "Memorize and repeat the block sequence",
                score: "SCORE",
                highScore: "HIGH SCORE",
                lives: "LIVES",
                startPrompt: "PRESS [SPACE] TO START",
                gameOver: "GAME OVER!",
                restartPrompt: "PRESS [SPACE] TO RESTART",
                controlsHelp: "Controls: Arrows or [A][D] to move | [SPACE] to fire"
            }
        }
    }
};
