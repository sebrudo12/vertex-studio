/**
 * ==============================================================================
 * VERTEX STUDIO - PANTALLA DE CARGA (LOADING SCREEN)
 * Interactive Engine, FiveM NUI Event Handler & Arcade Games
 * ==============================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
    App.init();
});

const App = {
    currentTabIndex: 0,
    currentTipIndex: 0,
    activeGame: 'space',
    isPlaying: false,
    isMuted: false,
    lastVolume: 0.25,
    audioElement: null,
    audioCtx: null,
    currentLang: 'es',
    isPerformanceMode: false,
    isCinemaMode: false,
    isMinigameOpen: false,
    isFiveM: false,

    init() {
        this.loadSavedPreferences();
        this.renderBranding();
        this.renderSocials();
        this.renderUpdates();
        this.renderRules();
        this.renderStaff();
        this.renderKeybinds();

        this.initAudioPlayer();
        this.initSoundEffects();
        this.initTabs();
        this.initTipsRotator();
        this.initBackgroundVideo();
        this.initFiveMLoadingEvents();
        this.initKeyboardControls();
        this.initTools();
        this.initMinigamesSuite();

        if (this.currentLang && this.currentLang !== 'es') {
            this.setLanguage(this.currentLang);
        }
    },

    // --------------------------------------------------------------------------
    // PERSISTENCIA INTELIGENTE (LOCALSTORAGE)
    // --------------------------------------------------------------------------
    loadSavedPreferences() {
        try {
            const savedVol = localStorage.getItem('vertex_volume');
            if (savedVol !== null) {
                this.lastVolume = parseFloat(savedVol);
            } else if (Config.audio && Config.audio.defaultVolume) {
                this.lastVolume = Config.audio.defaultVolume / 100;
            }

            const savedLang = localStorage.getItem('vertex_lang');
            if (savedLang) {
                this.currentLang = savedLang;
            }

            const savedPerf = localStorage.getItem('vertex_performance_mode');
            if (savedPerf === 'true') {
                this.isPerformanceMode = true;
            }
        } catch (e) {}
    },

    savePreference(key, value) {
        try {
            localStorage.setItem(key, value);
        } catch (e) {}
    },

    initBackgroundVideo() {
        const video = document.getElementById('background-video');
        if (video) {
            video.muted = true;
            if (this.isPerformanceMode) {
                document.body.classList.add('perf-mode-active');
                const btnPerf = document.getElementById('btn-perf-toggle');
                if (btnPerf) btnPerf.classList.add('active');
            } else {
                video.play().catch(() => {});
            }
        }
    },

    // --------------------------------------------------------------------------
    // RENDERIZADO DINÁMICO
    // --------------------------------------------------------------------------
    renderBranding() {
        const logoImgs = document.querySelectorAll('.brand-logo-img');
        logoImgs.forEach(img => {
            img.src = Config.studio.logo;
            img.alt = Config.studio.name;
        });

        const titleElems = document.querySelectorAll('.brand-title-text');
        titleElems.forEach(el => el.textContent = Config.studio.name);

        const taglineElems = document.querySelectorAll('.brand-tagline-text');
        taglineElems.forEach(el => el.textContent = Config.studio.tagline);
    },

    renderSocials() {
        const container = document.getElementById('header-socials-box');
        if (!container || !Config.socials) return;

        container.innerHTML = '';
        Config.socials.forEach(item => {
            const btn = document.createElement('a');
            btn.className = 'btn-social-action ' + (item.id === 'discord' ? 'highlight' : '');
            btn.href = item.url;
            btn.target = "_blank";

            if (item.id === 'discord') {
                const liveCount = item.fallbackOnline || '1,420';
                btn.innerHTML = '<i class="' + item.icon + '"></i> <span>' + item.name + '</span> <span class="live-status-dot"></span> <span id="discord-online-badge">' + liveCount + ' ' + App.getTranslation('discord.online') + '</span>';
                if (item.guildId) {
                    App.fetchDiscordWidget(item.guildId);
                }
            } else {
                btn.innerHTML = '<i class="' + item.icon + '"></i> <span>' + item.name + '</span>';
            }

            if (item.copyOnClick) {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    App.copyToClipboard(item.url, '¡Enlace copiado al portapapeles!');
                });
            }
            container.appendChild(btn);
        });
    },

    fetchDiscordWidget(guildId) {
        fetch('https://discord.com/api/guilds/' + guildId + '/widget.json')
            .then(res => res.json())
            .then(data => {
                if (data && typeof data.presence_count === 'number') {
                    const el = document.getElementById('discord-online-badge');
                    if (el) el.textContent = data.presence_count.toLocaleString() + ' ' + App.getTranslation('discord.online');
                }
            })
            .catch(() => {});
    },

    renderUpdates() {
        const container = document.getElementById('updates-list-content');
        if (!container || !Config.updates) return;

        container.innerHTML = '';
        Config.updates.forEach(up => {
            const item = document.createElement('div');
            item.className = 'update-entry';

            const listItems = up.items.map(li => '<li><i class="fas fa-angle-right"></i> <span>' + li + '</span></li>').join('');

            item.innerHTML = '<div class="update-header">' +
                '<div class="update-version-title">' +
                    '<span class="update-v-tag">' + up.version + ' - ' + up.title + '</span>' +
                    '<span class="badge-tag">' + up.badge + '</span>' +
                '</div>' +
                '<span class="update-date"><i class="far fa-calendar-alt"></i> ' + up.date + '</span>' +
            '</div>' +
            '<ul class="update-list">' + listItems + '</ul>';
            container.appendChild(item);
        });
    },

    renderRules() {
        const container = document.getElementById('rules-list-content');
        if (!container || !Config.rules) return;

        container.innerHTML = '';
        Config.rules.forEach(cat => {
            const section = document.createElement('div');
            const cardsHtml = cat.items.map(r => '<div class="rule-card">' +
                '<h4>' + r.title + '</h4>' +
                '<p>' + r.desc + '</p>' +
            '</div>').join('');

            section.innerHTML = '<div class="rule-category-title"><i class="fas fa-shield-alt"></i> ' + cat.category + '</div>' +
                '<div class="rule-cards-grid">' + cardsHtml + '</div>';
            container.appendChild(section);
        });
    },

    renderStaff() {
        const grid = document.getElementById('staff-grid-content');
        if (!grid || !Config.staff) return;

        grid.innerHTML = '';
        Config.staff.forEach(member => {
            const card = document.createElement('div');
            card.className = 'staff-card';
            card.innerHTML = '<div class="staff-avatar-frame">' +
                '<img src="' + (member.avatar || Config.studio.logo) + '" class="staff-avatar" alt="' + member.name + '" />' +
            '</div>' +
            '<span class="staff-name">' + member.name + '</span>' +
            '<span class="staff-role">' + member.role + '</span>' +
            '<p class="staff-desc">' + member.description + '</p>' +
            '<div class="staff-discord-tag">' +
                '<i class="fab fa-discord"></i> <span>' + member.discord + '</span>' +
            '</div>';
            grid.appendChild(card);
        });
    },

    renderKeybinds() {
        const grid = document.getElementById('keybinds-grid-content');
        if (!grid || !Config.keybinds) return;

        grid.innerHTML = '';
        Config.keybinds.forEach(bind => {
            const item = document.createElement('div');
            item.className = 'keybind-card';
            item.innerHTML = '<div class="keycap">' + bind.key + '</div>' +
                '<div class="keybind-details">' +
                    '<h4>' + bind.action + '</h4>' +
                    '<p>' + bind.desc + '</p>' +
                '</div>';
            grid.appendChild(item);
        });
    },

    // --------------------------------------------------------------------------
    // REPRODUCTOR DE AUDIO (LOCAL MUSIC.MP3)
    // --------------------------------------------------------------------------
    initAudioPlayer() {
        this.audioElement = new Audio();
        this.audioElement.loop = true;
        this.audioElement.volume = this.lastVolume;

        const audioSrc = (Config.audio && Config.audio.file) ? Config.audio.file : 'assets/music.mp3';
        this.audioElement.src = audioSrc;

        // Fallback automático si music.mp3 está en html/ o en html/assets/
        this.audioElement.addEventListener('error', () => {
            if (this.audioElement.src.includes('assets/music.mp3')) {
                this.audioElement.src = 'music.mp3';
                if (this.isPlaying) this.audioElement.play().catch(() => {});
            }
        });

        // Configurar título y artista
        const titleEl = document.getElementById('track-title-text');
        const artistEl = document.getElementById('track-artist-text');
        if (titleEl) titleEl.textContent = (Config.audio && Config.audio.title) || 'music.mp3';
        if (artistEl) artistEl.textContent = (Config.audio && Config.audio.artist) || 'Vertex Studio';

        const volSlider = document.getElementById('audio-volume-slider');
        if (volSlider) {
            volSlider.value = Math.round(this.lastVolume * 100);
            volSlider.addEventListener('input', (e) => {
                const vol = parseFloat(e.target.value) / 100;
                App.audioElement.volume = vol;
                App.lastVolume = vol;
                App.savePreference('vertex_volume', vol);
                App.updateMuteIcon(vol === 0);
            });
        }

        const btnPlay = document.getElementById('btn-play-pause');
        if (btnPlay) {
            btnPlay.addEventListener('click', () => App.togglePlay());
        }

        const btnMute = document.getElementById('btn-audio-mute');
        if (btnMute) {
            btnMute.addEventListener('click', () => App.toggleMute());
        }

        if (Config.audio && Config.audio.autoplay) {
            const playPromise = this.audioElement.play();
            if (playPromise !== undefined) {
                playPromise.then(() => {
                    App.isPlaying = true;
                    App.updatePlayStateUI();
                }).catch(() => {
                    const unlockAudio = () => {
                        App.audioElement.play();
                        App.isPlaying = true;
                        App.updatePlayStateUI();
                        window.removeEventListener('click', unlockAudio);
                        window.removeEventListener('keydown', unlockAudio);
                    };
                    window.addEventListener('click', unlockAudio);
                    window.addEventListener('keydown', unlockAudio);
                });
            }
        }
    },

    togglePlay() {
        if (this.audioElement.paused) {
            this.audioElement.play().catch(() => {});
            this.isPlaying = true;
        } else {
            this.audioElement.pause();
            this.isPlaying = false;
        }
        this.updatePlayStateUI();
        this.playUiSound(800, 0.05);
    },

    toggleMute() {
        if (this.audioElement.volume > 0) {
            this.lastVolume = this.audioElement.volume;
            this.audioElement.volume = 0;
            this.isMuted = true;
            const slider = document.getElementById('audio-volume-slider');
            if (slider) slider.value = 0;
        } else {
            this.audioElement.volume = this.lastVolume > 0 ? this.lastVolume : 0.25;
            this.isMuted = false;
            const slider = document.getElementById('audio-volume-slider');
            if (slider) slider.value = Math.round(this.audioElement.volume * 100);
        }
        this.updateMuteIcon(this.isMuted);
        this.playUiSound(650, 0.04);
    },

    updateMuteIcon(muted) {
        const icon = document.querySelector('#btn-audio-mute i');
        if (!icon) return;
        icon.className = muted ? 'fas fa-volume-mute' : 'fas fa-volume-up';
    },

    updatePlayStateUI() {
        const btnIcon = document.querySelector('#btn-play-pause i');
        const eq = document.querySelector('.audio-equalizer');

        if (this.isPlaying) {
            if (btnIcon) btnIcon.className = 'fas fa-pause';
            if (eq) eq.classList.add('playing');
        } else {
            if (btnIcon) btnIcon.className = 'fas fa-play';
            if (eq) eq.classList.remove('playing');
        }
    },

    initSoundEffects() {
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            this.audioCtx = new AudioContext();
        } catch (e) {}
    },

    playUiSound(frequency, duration) {
        if (!Config.audio || !Config.audio.enableSfx || !this.audioCtx) return;
        try {
            if (this.audioCtx.state === 'suspended') {
                this.audioCtx.resume();
            }
            const osc = this.audioCtx.createOscillator();
            const gain = this.audioCtx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(frequency, this.audioCtx.currentTime);
            gain.gain.setValueAtTime(0.04, this.audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, this.audioCtx.currentTime + duration);
            osc.connect(gain);
            gain.connect(this.audioCtx.destination);
            osc.start();
            osc.stop(this.audioCtx.currentTime + duration);
        } catch (e) {}
    },

    // --------------------------------------------------------------------------
    // NAVEGACIÓN POR PESTAÑAS
    // --------------------------------------------------------------------------
    initTabs() {
        const pills = document.querySelectorAll('.nav-pill');
        const panes = document.querySelectorAll('.tab-pane');

        pills.forEach((pill) => {
            pill.addEventListener('click', () => {
                pills.forEach(p => p.classList.remove('active'));
                panes.forEach(pane => pane.classList.remove('active'));

                pill.classList.add('active');
                const targetId = pill.getAttribute('data-tab');
                const targetPane = document.getElementById(targetId);
                if (targetPane) {
                    targetPane.classList.add('active');
                }
            });
        });
    },

    // --------------------------------------------------------------------------
    // ROTADOR DE CONSEJOS / TIPS
    // --------------------------------------------------------------------------
    initTipsRotator() {
        if (!Config.tips || Config.tips.length === 0) return;

        this.showTip(0);
        setInterval(() => {
            App.currentTipIndex = (App.currentTipIndex + 1) % Config.tips.length;
            App.showTip(App.currentTipIndex);
        }, Config.tipsInterval || 6000);
    },

    showTip(index) {
        const tip = Config.tips[index];
        const iconEl = document.getElementById('tip-icon');
        const catEl = document.getElementById('tip-category');
        const textEl = document.getElementById('tip-text');

        if (textEl) {
            textEl.style.opacity = '0';
            setTimeout(() => {
                if (iconEl) iconEl.className = tip.icon || 'fas fa-info-circle';
                if (catEl) catEl.textContent = tip.category || 'CONSEJO';
                textEl.textContent = tip.text;
                textEl.style.opacity = '1';
            }, 250);
        }
    },

    // --------------------------------------------------------------------------
    // CONTROLADOR NATIVO DE CARGA DE FIVEM (100% SINCRONIZADO)
    // --------------------------------------------------------------------------
    initFiveMLoadingEvents() {
        const progressBar = document.getElementById('progress-bar-fill');
        const percentText = document.getElementById('loading-percent');
        const statusText = document.getElementById('loading-status');

        let targetPercentage = 0;
        let displayedPercentage = 0;
        let lastStatusMessage = 'Conectando al servidor...';
        let simulationInterval = null;

        const stageCounts = {
            'INIT_BEFORE_MAP_LOADED': 1,
            'INIT_AFTER_MAP_LOADED': 1,
            'INIT_SESSION': 1
        };
        let totalDataFiles = 1;
        let currentDataFiles = 0;
        let totalMapFunctions = 1;

        const renderUI = () => {
            if (progressBar) progressBar.style.width = displayedPercentage.toFixed(1) + '%';
            if (percentText) percentText.textContent = Math.round(displayedPercentage) + '%';
            if (statusText) {
                statusText.innerHTML = '<i class="fas fa-circle-notch"></i> ' + lastStatusMessage;
            }
        };

        const updateTarget = (percent, status) => {
            if (percent > targetPercentage) {
                targetPercentage = Math.min(100, percent);
            }
            if (status) {
                lastStatusMessage = status;
            }
        };

        const smoothTick = () => {
            if (displayedPercentage < targetPercentage) {
                const diff = targetPercentage - displayedPercentage;
                displayedPercentage += Math.max(0.08, diff * 0.12);
                if (displayedPercentage > targetPercentage) {
                    displayedPercentage = targetPercentage;
                }
                renderUI();
            }
            requestAnimationFrame(smoothTick);
        };
        requestAnimationFrame(smoothTick);

        const onFiveMActive = () => {
            if (!App.isFiveM) {
                App.isFiveM = true;
                if (simulationInterval) {
                    clearInterval(simulationInterval);
                    simulationInterval = null;
                }
            }
        };

        window.addEventListener('message', (event) => {
            const data = event.data;
            if (!data || !data.eventName) return;

            onFiveMActive();

            switch (data.eventName) {
                case 'loadProgress': {
                    const fraction = typeof data.loadFraction === 'number' ? data.loadFraction : 0;
                    const percent = fraction * 50;
                    const displayPct = Math.round(fraction * 100);
                    updateTarget(percent, 'Descargando recursos del servidor (' + displayPct + '%)...');
                    break;
                }
                case 'startDataFileEntries': {
                    totalDataFiles = Math.max(1, data.count || 1);
                    currentDataFiles = 0;
                    updateTarget(50, 'Leyendo manifiestos y archivos de datos...');
                    break;
                }
                case 'onDataFileEntry': {
                    currentDataFiles++;
                    const progress = 50 + (currentDataFiles / totalDataFiles) * 10;
                    const fileName = data.name ? data.name.split('/').pop() : 'archivo';
                    updateTarget(progress, 'Cargando datos: ' + fileName);
                    break;
                }
                case 'startInitFunctionOrder': {
                    if (data.type && stageCounts.hasOwnProperty(data.type)) {
                        stageCounts[data.type] = Math.max(1, data.count || 1);
                    }
                    break;
                }
                case 'performMapLoadFunction': {
                    if (data.count) totalMapFunctions = data.count;
                    const idx = data.idx || 1;
                    const progress = 60 + (idx / totalMapFunctions) * 15;
                    updateTarget(progress, 'Cargando mapa, texturas e interiores...');
                    break;
                }
                case 'initFunctionInvoking': {
                    const idx = data.idx || 1;
                    const type = data.type || '';
                    const stageCount = stageCounts[type] || 50;

                    if (type === 'INIT_BEFORE_MAP_LOADED') {
                        const progress = 70 + (idx / stageCount) * 12;
                        const name = data.name || 'Motor de juego';
                        updateTarget(progress, 'Inicializando motor: ' + name);
                    } else if (type === 'INIT_AFTER_MAP_LOADED') {
                        const progress = 82 + (idx / stageCount) * 12;
                        const name = data.name || 'Recursos de servidor';
                        updateTarget(progress, 'Iniciando script: ' + name);
                    } else if (type === 'INIT_SESSION') {
                        const progress = 94 + (idx / stageCount) * 6;
                        updateTarget(progress, 'Sincronizando sesión multijugador...');
                    } else {
                        updateTarget(targetPercentage + 1, data.name || 'Cargando componentes...');
                    }
                    break;
                }
                case 'onLogLine': {
                    if (data.message) {
                        let msg = data.message.trim();
                        if (/downloading/i.test(msg)) {
                            msg = msg.replace(/downloading/i, 'Descargando:');
                        } else if (/loaded/i.test(msg)) {
                            msg = msg.replace(/loaded/i, 'Cargado:');
                        }
                        updateTarget(targetPercentage, msg);
                    }
                    break;
                }
                case 'endInitFunction': {
                    if (data.type === 'INIT_SESSION') {
                        updateTarget(100, '¡Carga finalizada! Entrando a la sesión...');
                    }
                    break;
                }
            }
        });

        setTimeout(() => {
            if (!App.isFiveM) {
                let simulated = 0;
                const statusSteps = [
                    'Iniciando protocolos de conexión...',
                    'Descargando shaders y texturas...',
                    'Sincronizando paquetes de scripts Vertex Studio...',
                    'Cargando interiores y colisiones...',
                    'Iniciando sesión multijugador...',
                    '¡Conexión establecida con éxito!'
                ];

                simulationInterval = setInterval(() => {
                    if (App.isFiveM) {
                        clearInterval(simulationInterval);
                        return;
                    }

                    simulated += Math.random() * 4 + 1.8;
                    const stepIdx = Math.floor((simulated / 100) * statusSteps.length);
                    const currentStatus = statusSteps[Math.min(stepIdx, statusSteps.length - 1)];

                    if (simulated >= 100) {
                        simulated = 100;
                        updateTarget(100, '¡Carga completada! Entrando a la sesión...');
                        clearInterval(simulationInterval);
                    } else {
                        updateTarget(simulated, currentStatus);
                    }
                }, 300);
            }
        }, 1500);
    },

    // --------------------------------------------------------------------------
    // CONTROLES DE TECLADO
    // --------------------------------------------------------------------------
    initKeyboardControls() {
        window.addEventListener('keydown', (e) => {
            if (e.code === 'Space') {
                if (App.isMinigameOpen) return;
                e.preventDefault();
                App.togglePlay();
            } else if (e.code === 'KeyM') {
                if (App.isMinigameOpen) return;
                e.preventDefault();
                App.toggleMute();
            } else if (e.code === 'KeyJ') {
                e.preventDefault();
                App.toggleMinigame();
            } else if (e.code === 'KeyH') {
                e.preventDefault();
                App.toggleCinemaMode();
            } else if (e.code === 'Escape') {
                if (App.isCinemaMode) {
                    App.exitCinemaMode();
                    return;
                }
                if (App.isMinigameOpen) App.closeMinigame();
            }
        });
    },

    // --------------------------------------------------------------------------
    // IDIOMA & HERRAMIENTAS
    // --------------------------------------------------------------------------
    initTools() {
        const btnLang = document.getElementById('btn-lang-toggle');
        if (btnLang) {
            btnLang.addEventListener('click', () => {
                const nextLang = App.currentLang === 'es' ? 'en' : 'es';
                App.setLanguage(nextLang);
            });
        }

        const cinemaExit = document.getElementById('cinema-exit-badge');
        if (cinemaExit) {
            cinemaExit.addEventListener('click', (e) => {
                e.stopPropagation();
                App.exitCinemaMode();
            });
        }

        const btnPerf = document.getElementById('btn-perf-toggle');
        if (btnPerf) {
            if (App.isPerformanceMode) {
                btnPerf.classList.add('active');
            }
            btnPerf.addEventListener('click', () => {
                App.togglePerformanceMode();
            });
        }

        // Si se hace clic en cualquier lugar mientras está activo el Modo Cine, se desactiva
        document.addEventListener('click', (e) => {
            if (App.isCinemaMode) {
                if (!e.target.closest('#cinema-exit-badge')) {
                    App.exitCinemaMode();
                }
            }
        });
    },

    toggleCinemaMode() {
        this.isCinemaMode = !this.isCinemaMode;
        document.body.classList.toggle('cinema-mode-active', this.isCinemaMode);

        if (this.isCinemaMode) {
            if (this.isMinigameOpen) this.closeMinigame();
            this.showToast(this.getTranslation('cinema.active') || 'Modo Cine Activado (Presiona [H] o haz clic para salir)');
        }
        this.playUiSound(900, 0.05);
    },

    exitCinemaMode() {
        if (!this.isCinemaMode) return;
        this.isCinemaMode = false;
        document.body.classList.remove('cinema-mode-active');
        this.playUiSound(700, 0.05);
    },

    togglePerformanceMode() {
        this.isPerformanceMode = !this.isPerformanceMode;
        this.savePreference('vertex_performance_mode', this.isPerformanceMode ? 'true' : 'false');

        const video = document.getElementById('background-video');
        const btnPerf = document.getElementById('btn-perf-toggle');

        if (this.isPerformanceMode) {
            document.body.classList.add('perf-mode-active');
            if (btnPerf) btnPerf.classList.add('active');
            if (video) video.pause();
            this.showToast(this.getTranslation('performance.enabled') || 'Modo Rendimiento Activado: Video pausado para ahorro de GPU');
        } else {
            document.body.classList.remove('perf-mode-active');
            if (btnPerf) btnPerf.classList.remove('active');
            if (video) video.play().catch(() => {});
            this.showToast(this.getTranslation('performance.disabled') || 'Modo Rendimiento Desactivado: Video reanudado');
        }
        this.playUiSound(850, 0.05);
    },

    showToast(text) {
        const toast = document.getElementById('toast-notification');
        const toastText = document.getElementById('toast-text');
        if (!toast) return;
        if (toastText) toastText.textContent = text;
        toast.classList.add('show');
        if (this.toastTimeout) clearTimeout(this.toastTimeout);
        this.toastTimeout = setTimeout(() => {
            toast.classList.remove('show');
        }, 3200);
    },

    copyToClipboard(text, successMsg) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(() => {
                this.showToast(successMsg || '¡Enlace copiado al portapapeles!');
            }).catch(() => {
                this.fallbackCopy(text, successMsg);
            });
        } else {
            this.fallbackCopy(text, successMsg);
        }
    },

    fallbackCopy(text, successMsg) {
        const temp = document.createElement('textarea');
        temp.value = text;
        temp.style.position = 'fixed';
        temp.style.opacity = '0';
        document.body.appendChild(temp);
        temp.focus();
        temp.select();
        try {
            document.execCommand('copy');
            this.showToast(successMsg || '¡Enlace copiado al portapapeles!');
        } catch (err) {}
        document.body.removeChild(temp);
    },

    setLanguage(lang) {
        if (!Config.translations || !Config.translations[lang]) return;
        App.currentLang = lang;
        App.savePreference('vertex_lang', lang);

        const langLabel = document.getElementById('lang-label');
        if (langLabel) langLabel.textContent = lang.toUpperCase();

        const dict = Config.translations[lang];

        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            const val = App.getNestedValue(dict, key);
            if (val) el.textContent = val;
        });

        const discordCount = document.getElementById('discord-online-badge');
        if (discordCount) {
            const parts = discordCount.textContent.split(' ');
            const num = parts[0] || '1,420';
            discordCount.textContent = num + ' ' + dict.discord.online;
        }
    },

    getTranslation(path) {
        if (!Config.translations) return '';
        const dict = Config.translations[App.currentLang] || Config.translations.es;
        return App.getNestedValue(dict, path) || '';
    },

    getNestedValue(obj, path) {
        return path.split('.').reduce((acc, part) => acc && acc[part], obj);
    },

    // --------------------------------------------------------------------------
    // SUITE DE 3 MINIJUEGOS (SPACE DEFENDER + NEON SNAKE + MEMORY HACK)
    // --------------------------------------------------------------------------
    initMinigamesSuite() {
        const modal = document.getElementById('minigame-modal');
        const btnOpen = document.getElementById('btn-open-minigame');
        const btnClose = document.getElementById('btn-close-minigame');
        const tabBtns = document.querySelectorAll('.btn-game-tab');

        if (btnOpen) {
            btnOpen.addEventListener('click', () => App.openMinigame());
        }
        if (btnClose) {
            btnClose.addEventListener('click', () => App.closeMinigame());
        }

        tabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const game = btn.getAttribute('data-game');
                App.switchMinigame(game);
                App.playUiSound(700, 0.04);
            });
        });

        this.initSpaceDefender();
        this.initNeonSnake();
        this.initMemoryHack();
    },

    switchMinigame(game) {
        this.activeGame = game;

        const tabBtns = document.querySelectorAll('.btn-game-tab');
        tabBtns.forEach(b => b.classList.toggle('active', b.getAttribute('data-game') === game));

        const spaceCanvas = document.getElementById('minigame-canvas');
        const snakeCanvas = document.getElementById('snake-canvas');
        const hackView = document.getElementById('hack-game-view');
        const livesBox = document.getElementById('game-lives-box');
        const overlay = document.getElementById('game-overlay-screen');

        if (spaceCanvas) spaceCanvas.style.display = 'none';
        if (snakeCanvas) snakeCanvas.style.display = 'none';
        if (hackView) hackView.style.display = 'none';
        if (overlay) overlay.classList.add('hidden');

        const headerIcon = document.getElementById('minigame-header-icon');
        const headerTitle = document.getElementById('minigame-header-title');
        const headerSubtitle = document.getElementById('minigame-header-subtitle');

        if (game === 'space') {
            if (spaceCanvas) spaceCanvas.style.display = 'block';
            if (livesBox) livesBox.style.display = 'flex';
            if (headerIcon) headerIcon.className = 'fas fa-rocket';
            if (headerTitle) headerTitle.textContent = 'VERTEX SPACE DEFENDER';
            if (headerSubtitle) headerSubtitle.textContent = App.getTranslation('minigame.spaceDesc') || 'Defiende el núcleo destruyendo cristales espaciales';
            App.updateScoreUI(App.spaceScore, App.spaceHighScore, App.spaceLives);
        } else if (game === 'snake') {
            if (snakeCanvas) snakeCanvas.style.display = 'block';
            if (livesBox) livesBox.style.display = 'none';
            if (headerIcon) headerIcon.className = 'fas fa-dragon';
            if (headerTitle) headerTitle.textContent = 'NEON SNAKE';
            if (headerSubtitle) headerSubtitle.textContent = App.getTranslation('minigame.snakeDesc') || 'Come diamantes de datos y evita chocar';
            App.updateScoreUI(App.snakeScore, App.snakeHighScore, null);
        } else if (game === 'hack') {
            if (hackView) hackView.style.display = 'flex';
            if (livesBox) livesBox.style.display = 'none';
            if (headerIcon) headerIcon.className = 'fas fa-terminal';
            if (headerTitle) headerTitle.textContent = 'FIVEM MEMORY HACK';
            if (headerSubtitle) headerSubtitle.textContent = App.getTranslation('minigame.hackDesc') || 'Memoriza y reproduce la secuencia de bloques';
            App.updateScoreUI(App.hackScore, App.hackHighScore, null);
        }
    },

    updateScoreUI(score, high, lives) {
        const scoreEl = document.getElementById('game-score');
        const highEl = document.getElementById('game-highscore');
        const livesEl = document.getElementById('game-lives');

        if (scoreEl) scoreEl.textContent = score || 0;
        if (highEl) highEl.textContent = high || 0;
        if (livesEl && lives !== null && lives !== undefined) livesEl.textContent = lives;
    },

    toggleMinigame() {
        if (App.isMinigameOpen) {
            App.closeMinigame();
        } else {
            App.openMinigame();
        }
    },

    openMinigame() {
        const modal = document.getElementById('minigame-modal');
        if (!modal) return;
        App.isMinigameOpen = true;
        modal.classList.add('active');
    },

    closeMinigame() {
        const modal = document.getElementById('minigame-modal');
        if (!modal) return;
        App.isMinigameOpen = false;
        modal.classList.remove('active');
    },

    // --------------------------------------------------------------------------
    // JUEGO 1: SPACE DEFENDER
    // --------------------------------------------------------------------------
    spaceScore: 0,
    spaceHighScore: 0,
    spaceLives: 3,

    initSpaceDefender() {
        const canvas = document.getElementById('minigame-canvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');

        const overlay = document.getElementById('game-overlay-screen');
        const overlayTitle = document.getElementById('game-overlay-title');
        const overlayPrompt = document.getElementById('game-overlay-prompt');
        const overlayControls = document.getElementById('game-overlay-controls');

        this.spaceHighScore = parseInt(localStorage.getItem('vertex_defender_high') || '0', 10);

        let gameState = 'START';
        let frameCount = 0;

        const player = {
            x: canvas.width / 2,
            y: canvas.height - 40,
            width: 32,
            height: 28,
            speed: 6.5
        };

        let bullets = [];
        let enemies = [];
        let particles = [];
        const keys = {};

        window.addEventListener('keydown', (e) => {
            if (!App.isMinigameOpen || App.activeGame !== 'space') return;
            keys[e.code] = true;

            if (e.code === 'Space') {
                e.preventDefault();
                if (gameState === 'START' || gameState === 'GAMEOVER') {
                    startGame();
                } else if (gameState === 'PLAYING') {
                    shootBullet();
                }
            }
        });

        window.addEventListener('keyup', (e) => {
            if (!App.isMinigameOpen || App.activeGame !== 'space') return;
            keys[e.code] = false;
        });

        function startGame() {
            gameState = 'PLAYING';
            App.spaceScore = 0;
            App.spaceLives = 3;
            bullets = [];
            enemies = [];
            particles = [];
            player.x = canvas.width / 2;
            App.updateScoreUI(App.spaceScore, App.spaceHighScore, App.spaceLives);
            if (overlay) overlay.classList.add('hidden');
        }

        function shootBullet() {
            bullets.push({
                x: player.x,
                y: player.y - 14,
                vx: 0,
                vy: -9.5,
                radius: 3
            });
            App.playUiSound(950, 0.04);
        }

        function spawnEnemy() {
            enemies.push({
                x: Math.random() * (canvas.width - 60) + 30,
                y: -20,
                radius: Math.random() * 8 + 12,
                vy: Math.random() * 1.6 + 1.2,
                angle: 0,
                spin: (Math.random() - 0.5) * 0.08
            });
        }

        function createExplosion(x, y, color) {
            for (let i = 0; i < 14; i++) {
                particles.push({
                    x, y,
                    vx: (Math.random() - 0.5) * 6,
                    vy: (Math.random() - 0.5) * 6,
                    life: 25,
                    color: color || '#ffffff'
                });
            }
        }

        function gameLoop() {
            if (App.activeGame === 'space' && App.isMinigameOpen) {
                ctx.clearRect(0, 0, canvas.width, canvas.height);

                if (gameState === 'PLAYING') {
                    frameCount++;

                    if (keys['ArrowLeft'] || keys['KeyA']) {
                        player.x = Math.max(player.width, player.x - player.speed);
                    }
                    if (keys['ArrowRight'] || keys['KeyD']) {
                        player.x = Math.min(canvas.width - player.width, player.x + player.speed);
                    }

                    if (frameCount % 55 === 0) {
                        spawnEnemy();
                    }

                    for (let i = bullets.length - 1; i >= 0; i--) {
                        const b = bullets[i];
                        b.y += b.vy;
                        ctx.beginPath();
                        ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
                        ctx.fillStyle = '#ffffff';
                        ctx.shadowBlur = 12;
                        ctx.shadowColor = '#00f0ff';
                        ctx.fill();
                        ctx.shadowBlur = 0;

                        if (b.y < -10) bullets.splice(i, 1);
                    }

                    for (let i = enemies.length - 1; i >= 0; i--) {
                        const en = enemies[i];
                        en.y += en.vy;
                        en.angle += en.spin;

                        ctx.save();
                        ctx.translate(en.x, en.y);
                        ctx.rotate(en.angle);
                        ctx.beginPath();
                        ctx.moveTo(0, -en.radius);
                        ctx.lineTo(en.radius * 0.85, 0);
                        ctx.lineTo(0, en.radius);
                        ctx.lineTo(-en.radius * 0.85, 0);
                        ctx.closePath();
                        ctx.strokeStyle = '#cbd5e1';
                        ctx.lineWidth = 2;
                        ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
                        ctx.fill();
                        ctx.stroke();
                        ctx.restore();

                        for (let j = bullets.length - 1; j >= 0; j--) {
                            const b = bullets[j];
                            const dx = en.x - b.x;
                            const dy = en.y - b.y;
                            if (Math.sqrt(dx * dx + dy * dy) < en.radius + b.radius) {
                                createExplosion(en.x, en.y, '#e2e8f0');
                                enemies.splice(i, 1);
                                bullets.splice(j, 1);
                                App.spaceScore += 100;
                                if (App.spaceScore > App.spaceHighScore) {
                                    App.spaceHighScore = App.spaceScore;
                                    App.savePreference('vertex_defender_high', App.spaceHighScore);
                                }
                                App.updateScoreUI(App.spaceScore, App.spaceHighScore, App.spaceLives);
                                App.playUiSound(500, 0.06);
                                break;
                            }
                        }

                        if (en && en.y > canvas.height - 20) {
                            createExplosion(en.x, en.y, '#ef4444');
                            enemies.splice(i, 1);
                            App.spaceLives--;
                            App.updateScoreUI(App.spaceScore, App.spaceHighScore, App.spaceLives);
                            App.playUiSound(200, 0.15);

                            if (App.spaceLives <= 0) {
                                gameState = 'GAMEOVER';
                                if (overlayTitle) overlayTitle.textContent = App.getTranslation('minigame.gameOver') || '¡MISIÓN FALLIDA!';
                                if (overlayPrompt) overlayPrompt.textContent = App.getTranslation('minigame.restartPrompt') || 'PRESIONA [ESPACIO] PARA REINICIAR';
                                if (overlayControls) overlayControls.textContent = 'Controles: Flechas o [A][D] para mover | [ESPACIO] para disparar';
                                if (overlay) overlay.classList.remove('hidden');
                            }
                        }
                    }

                    for (let i = particles.length - 1; i >= 0; i--) {
                        const p = particles[i];
                        p.x += p.vx;
                        p.y += p.vy;
                        p.life--;
                        ctx.beginPath();
                        ctx.arc(p.x, p.y, 2, 0, Math.PI * 2);
                        ctx.fillStyle = p.color;
                        ctx.globalAlpha = p.life / 25;
                        ctx.fill();
                        ctx.globalAlpha = 1;
                        if (p.life <= 0) particles.splice(i, 1);
                    }

                    // Nave "V"
                    ctx.save();
                    ctx.translate(player.x, player.y);
                    ctx.beginPath();
                    ctx.moveTo(0, -18);
                    ctx.lineTo(16, 12);
                    ctx.lineTo(8, 6);
                    ctx.lineTo(0, 10);
                    ctx.lineTo(-8, 6);
                    ctx.lineTo(-16, 12);
                    ctx.closePath();
                    ctx.fillStyle = '#ffffff';
                    ctx.shadowBlur = 14;
                    ctx.shadowColor = 'rgba(255, 255, 255, 0.85)';
                    ctx.fill();
                    ctx.restore();
                }
            }
            requestAnimationFrame(gameLoop);
        }
        requestAnimationFrame(gameLoop);
    },

    // --------------------------------------------------------------------------
    // JUEGO 2: NEON SNAKE
    // --------------------------------------------------------------------------
    snakeScore: 0,
    snakeHighScore: 0,

    initNeonSnake() {
        const canvas = document.getElementById('snake-canvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');

        const overlay = document.getElementById('game-overlay-screen');
        const overlayTitle = document.getElementById('game-overlay-title');
        const overlayPrompt = document.getElementById('game-overlay-prompt');
        const overlayControls = document.getElementById('game-overlay-controls');

        this.snakeHighScore = parseInt(localStorage.getItem('vertex_snake_high') || '0', 10);

        const gridSize = 20;
        const cols = Math.floor(canvas.width / gridSize);
        const rows = Math.floor(canvas.height / gridSize);

        let snake = [];
        let food = { x: 10, y: 10 };
        let dir = { x: 1, y: 0 };
        let nextDir = { x: 1, y: 0 };
        let snakeGameState = 'START';
        let snakeSpeedMs = 90;
        let lastMoveTime = 0;

        window.addEventListener('keydown', (e) => {
            if (!App.isMinigameOpen || App.activeGame !== 'snake') return;

            if (['ArrowUp', 'KeyW'].includes(e.code) && dir.y === 0) {
                nextDir = { x: 0, y: -1 };
            } else if (['ArrowDown', 'KeyS'].includes(e.code) && dir.y === 0) {
                nextDir = { x: 0, y: 1 };
            } else if (['ArrowLeft', 'KeyA'].includes(e.code) && dir.x === 0) {
                nextDir = { x: -1, y: 0 };
            } else if (['ArrowRight', 'KeyD'].includes(e.code) && dir.x === 0) {
                nextDir = { x: 1, y: 0 };
            } else if (e.code === 'Space') {
                e.preventDefault();
                if (snakeGameState === 'START' || snakeGameState === 'GAMEOVER') {
                    startSnakeGame();
                }
            }
        });

        function startSnakeGame() {
            snakeGameState = 'PLAYING';
            App.snakeScore = 0;
            dir = { x: 1, y: 0 };
            nextDir = { x: 1, y: 0 };
            snake = [
                { x: 8, y: 10 },
                { x: 7, y: 10 },
                { x: 6, y: 10 }
            ];
            spawnFood();
            App.updateScoreUI(App.snakeScore, App.snakeHighScore, null);
            if (overlay) overlay.classList.add('hidden');
        }

        function spawnFood() {
            let valid = false;
            while (!valid) {
                food = {
                    x: Math.floor(Math.random() * cols),
                    y: Math.floor(Math.random() * rows)
                };
                valid = !snake.some(seg => seg.x === food.x && seg.y === food.y);
            }
        }

        function snakeLoop(time) {
            if (App.activeGame === 'snake' && App.isMinigameOpen) {
                ctx.clearRect(0, 0, canvas.width, canvas.height);

                ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
                ctx.lineWidth = 1;
                for (let x = 0; x < canvas.width; x += gridSize) {
                    ctx.beginPath();
                    ctx.moveTo(x, 0);
                    ctx.lineTo(x, canvas.height);
                    ctx.stroke();
                }
                for (let y = 0; y < canvas.height; y += gridSize) {
                    ctx.beginPath();
                    ctx.moveTo(0, y);
                    ctx.lineTo(canvas.width, y);
                    ctx.stroke();
                }

                if (snakeGameState === 'PLAYING') {
                    if (time - lastMoveTime > snakeSpeedMs) {
                        lastMoveTime = time;
                        dir = nextDir;

                        const head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };

                        if (head.x < 0 || head.x >= cols || head.y < 0 || head.y >= rows) {
                            gameOverSnake();
                            return;
                        }

                        if (snake.some(seg => seg.x === head.x && seg.y === head.y)) {
                            gameOverSnake();
                            return;
                        }

                        snake.unshift(head);

                        if (head.x === food.x && head.y === food.y) {
                            App.snakeScore += 10;
                            if (App.snakeScore > App.snakeHighScore) {
                                App.snakeHighScore = App.snakeScore;
                                App.savePreference('vertex_snake_high', App.snakeHighScore);
                            }
                            App.updateScoreUI(App.snakeScore, App.snakeHighScore, null);
                            App.playUiSound(880, 0.05);
                            spawnFood();
                        } else {
                            snake.pop();
                        }
                    }

                    // Comida
                    ctx.save();
                    ctx.fillStyle = '#00f0ff';
                    ctx.shadowColor = '#00f0ff';
                    ctx.shadowBlur = 15;
                    ctx.beginPath();
                    const cx = food.x * gridSize + gridSize / 2;
                    const cy = food.y * gridSize + gridSize / 2;
                    ctx.moveTo(cx, cy - gridSize / 2 + 2);
                    ctx.lineTo(cx + gridSize / 2 - 2, cy);
                    ctx.lineTo(cx, cy + gridSize / 2 - 2);
                    ctx.lineTo(cx - gridSize / 2 + 2, cy);
                    ctx.closePath();
                    ctx.fill();
                    ctx.restore();

                    // Serpiente
                    snake.forEach((seg, i) => {
                        ctx.save();
                        ctx.fillStyle = i === 0 ? '#ffffff' : '#cbd5e1';
                        ctx.shadowColor = i === 0 ? 'rgba(255, 255, 255, 0.8)' : 'rgba(0, 240, 255, 0.4)';
                        ctx.shadowBlur = i === 0 ? 12 : 6;
                        ctx.fillRect(seg.x * gridSize + 1, seg.y * gridSize + 1, gridSize - 2, gridSize - 2);
                        ctx.restore();
                    });
                }
            }
            requestAnimationFrame(snakeLoop);
        }

        function gameOverSnake() {
            snakeGameState = 'GAMEOVER';
            App.playUiSound(180, 0.18);
            if (overlayTitle) overlayTitle.textContent = '¡SERPIENTE CAÍDA!';
            if (overlayPrompt) overlayPrompt.textContent = 'PRESIONA [ESPACIO] PARA REINTENTAR';
            if (overlayControls) overlayControls.textContent = 'Controles: Flechas o [W][A][S][D] para mover';
            if (overlay) overlay.classList.remove('hidden');
        }

        requestAnimationFrame(snakeLoop);
    },

    // --------------------------------------------------------------------------
    // JUEGO 3: FIVEM MEMORY HACK (4x4 MATRIX)
    // --------------------------------------------------------------------------
    hackScore: 0,
    hackHighScore: 0,
    hackRound: 1,
    hackSequence: [],
    playerSequence: [],
    isShowingSequence: false,

    initMemoryHack() {
        const grid = document.getElementById('hack-matrix-grid');
        const btnStart = document.getElementById('btn-start-hack');
        if (!grid) return;

        this.hackHighScore = parseInt(localStorage.getItem('vertex_hack_high') || '0', 10);

        grid.innerHTML = '';
        for (let i = 0; i < 16; i++) {
            const tile = document.createElement('div');
            tile.className = 'hack-tile';
            tile.setAttribute('data-index', i);
            tile.addEventListener('click', () => App.handleHackTileClick(i, tile));
            grid.appendChild(tile);
        }

        if (btnStart) {
            btnStart.addEventListener('click', () => App.startHackRound(1));
        }
    },

    startHackRound(round) {
        this.hackRound = round;
        this.playerSequence = [];
        this.hackSequence = [];
        this.isShowingSequence = true;

        const roundBadge = document.getElementById('hack-round-badge');
        const statusText = document.getElementById('hack-matrix-status');
        const btnStart = document.getElementById('btn-start-hack');

        if (roundBadge) roundBadge.textContent = 'Ronda ' + round + '/5';
        if (statusText) statusText.textContent = 'MEMORIZA LA SECUENCIA...';
        if (btnStart) btnStart.style.display = 'none';

        const count = round + 2;
        const availableTiles = Array.from({ length: 16 }, (_, i) => i);
        availableTiles.sort(() => Math.random() - 0.5);
        this.hackSequence = availableTiles.slice(0, count);

        let step = 0;
        const interval = setInterval(() => {
            if (step >= this.hackSequence.length) {
                clearInterval(interval);
                App.isShowingSequence = false;
                if (statusText) statusText.textContent = '¡REPITE LA SECUENCIA AHORA!';
                return;
            }

            const tileIdx = App.hackSequence[step];
            App.flashTile(tileIdx);
            step++;
        }, 600);
    },

    flashTile(index) {
        const tiles = document.querySelectorAll('.hack-tile');
        const tile = tiles[index];
        if (!tile) return;

        tile.classList.add('flash');
        App.playUiSound(700 + index * 40, 0.1);
        setTimeout(() => {
            tile.classList.remove('flash');
        }, 350);
    },

    handleHackTileClick(index, tile) {
        if (this.isShowingSequence || this.hackSequence.length === 0) return;

        this.playerSequence.push(index);
        const currentIndex = this.playerSequence.length - 1;

        if (this.hackSequence[currentIndex] === index) {
            tile.classList.add('correct');
            App.playUiSound(850 + currentIndex * 60, 0.08);
            setTimeout(() => tile.classList.remove('correct'), 300);

            if (this.playerSequence.length === this.hackSequence.length) {
                App.hackScore += this.hackRound * 250;
                if (App.hackScore > App.hackHighScore) {
                    App.hackHighScore = App.hackScore;
                    App.savePreference('vertex_hack_high', App.hackHighScore);
                }
                App.updateScoreUI(App.hackScore, App.hackHighScore, null);

                if (this.hackRound >= 5) {
                    const statusText = document.getElementById('hack-matrix-status');
                    if (statusText) statusText.textContent = '¡ACCESO CONCEDIDO! HACKEO COMPLETADO';
                    App.playUiSound(1200, 0.25);
                    const btnStart = document.getElementById('btn-start-hack');
                    if (btnStart) {
                        btnStart.textContent = 'JUGAR DE NUEVO';
                        btnStart.style.display = 'block';
                    }
                } else {
                    const statusText = document.getElementById('hack-matrix-status');
                    if (statusText) statusText.textContent = '¡CORRECTO! SIGUIENTE NIVEL...';
                    setTimeout(() => {
                        App.startHackRound(App.hackRound + 1);
                    }, 1000);
                }
            }
        } else {
            tile.classList.add('wrong');
            App.playUiSound(200, 0.2);
            setTimeout(() => tile.classList.remove('wrong'), 400);

            const statusText = document.getElementById('hack-matrix-status');
            if (statusText) statusText.textContent = '¡FALLO EN EL FIREWALL! INTÉNTALO DE NUEVO';
            const btnStart = document.getElementById('btn-start-hack');
            if (btnStart) {
                btnStart.textContent = 'REINTENTAR HACKEO';
                btnStart.style.display = 'block';
            }
        }
    },

    // --------------------------------------------------------------------------
    // UTILIDADES: TOAST & COPIAR
    // --------------------------------------------------------------------------
    copyToClipboard(text, message) {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(() => {
                App.showToast(message);
            }).catch(() => {
                App.fallbackCopy(text, message);
            });
        } else {
            App.fallbackCopy(text, message);
        }
    },

    fallbackCopy(text, message) {
        const temp = document.createElement('input');
        temp.value = text;
        document.body.appendChild(temp);
        temp.select();
        document.execCommand('copy');
        document.body.removeChild(temp);
        App.showToast(message);
    },

    showToast(message) {
        const toast = document.getElementById('toast-notification');
        const textEl = document.getElementById('toast-text');
        if (!toast) return;

        if (textEl) textEl.textContent = message;
        toast.classList.add('show');
        App.playUiSound(1200, 0.08);

        setTimeout(() => {
            toast.classList.remove('show');
        }, 3200);
    }
};
