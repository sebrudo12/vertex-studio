﻿MIT License / Vertex Studio Commercial License

Copyright (c) 2026 Vertex Studio

Se concede permiso, libre de cargos, a cualquier persona que obtenga una copia de este software y los archivos de documentación asociados (el "Software"), para utilizar, configurar y ejecutar el Software en sus servidores de FiveM, sujeto a las siguientes condiciones:

1. El aviso de copyright anterior y este aviso de permiso se incluirán en todas las copias o partes sustanciales del Software.
2. Queda expresamente prohibida la reventa, sublicencia, redistribución pública no autorizada o adjudicación de autoría original sin el consentimiento explícito de Vertex Studio.

EL SOFTWARE SE PROPORCIONA "TAL CUAL", SIN GARANTÍA DE NINGÚN TIPO, EXPRESA O IMPLÍCITA, INCLUYENDO PERO NO LIMITADO A GARANTÍAS DE COMERCIALIZACIÓN, IDONEIDAD PARA UN PROPÓSITO PARTICULAR Y NO INFRACCIÓN. EN NINGÚN CASO LOS AUTORES O TITULARES DEL COPYRIGHT SERÁN RESPONSABLES DE NINGUNA RECLAMACIÓN, DAÑOS U OTRAS RESPONSABILIDADES.
