﻿# 🚀 Vertex Studio - Pantalla de Carga (Loading Screen) para FiveM

Pantalla de carga AAA de última generación para **FiveM**, diseñada exclusivamente con la identidad visual oficial de **Vertex Studio**: acabados en titanio cepillado, cromo pulido, negro obsidiana, reflejos metálicos sutiles y un viewport completamente limpio para lucir al máximo el video de fondo g.mp4 y tu música local music.mp3.

Inspirada en las mejores directrices visuales de estudios referentes (**Tuff**, **Wasabi** y **UM-Ronin**), optimizada y 100% libre de saturación o dependencias externas.

---

## 🌟 Características Principales

- 💎 **Diseño Cyber-Chrome Glassmorphism Minimalista:**
  - Centro de la pantalla 100% despejado en la pestaña de Inicio para apreciar el video de fondo en alta resolución.
  - Sin mallas de puntos, sin partículas invasivas ni cuadros flotantes que tapen la imagen.
  - Tipografías modernas (*Orbitron* & *Rajdhani*) con acentos en cromo y titanio.

- 🎵 **Música Local music.mp3 con Reproducción en Bucle:**
  - Reproduce tu archivo local music.mp3 colocado en html/assets/music.mp3 (o html/music.mp3).
  - **Cero dependencias de internet:** La música carga instantáneamente sin depender de enlaces externos que puedan fallar o demorar la carga.
  - Ecualizador dinámico interactivo con animación Cyber-Chrome.
  - Control de volumen interactivo con slider suave y guardado en memoria.
  - Control rápido por teclado con **ESPACIO** (pausa/reanudación) y **M** (silencio/mute).

- 🎬 **Modo Cine Inmersivo (Tecla H):**
  - Oculta instantáneamente toda la interfaz de usuario con un desvanecimiento suave para disfrutar del video de fondo y la música sin distracciones.
  - Al presionar de nuevo H, ESC o hacer clic en cualquier parte de la pantalla, la interfaz reaparece suavemente.

- 🔋 **Modo Rendimiento (Eco GPU / Low-End PC):**
  - Botón en la barra superior que pausa el video de fondo y desactiva filtros GPU pesados (ackdrop-filter).
  - Ideal para jugadores con tarjetas gráficas modestas o laptops, liberando el 100% de la GPU durante descargas pesadas de recursos.
  - Su estado se recuerda automáticamente entre conexiones.

- 🕹️ **Arcade Suite Integrada (3 Minijuegos con Récords Locales):**
  - **Vertex Space Defender:** Clásico shooter espacial destruyendo asteroides y cristales cibernéticos.
  - **Neon Snake:** La mítica serpiente retro con estética neón cian.
  - **FiveM Memory Hack:** Minijuego de hackeo de robos de FiveM (matriz 4x4) con secuencias de memorización progresivas.
  - Guarda automáticamente los récords de puntuación del jugador en localStorage.
  - Accesible desde la barra superior o presionando la tecla **J**.

- 💾 **Memoria Inteligente (LocalStorage Persistence):**
  - Recuerda el nivel de volumen exacto elegido por el usuario.
  - Recuerda el idioma preferido (ES o EN).
  - Recuerda si el usuario activó el Modo Rendimiento (Eco GPU).
  - Recuerda los récords alcanzados en los minijuegos.

- 👥 **Discord Live Widget & Enlaces Oficiales:**
  - Luz de pulso en vivo y contador de usuarios conectados en el Discord oficial.
  - Acceso directo a la Tienda Oficial de Vertex Studio.

- 🌐 **Soporte Bilingüe Integrado (ES / EN):**
  - Cambio dinámico e instantáneo de idioma con persistencia en memoria.

- 📊 **Carga Real Sincronizada con FiveM:**
  - Escucha precisa de las 5 etapas del ciclo de vida NUI de FiveM (loadProgress, startDataFileEntries, performMapLoadFunction, initFunctionInvoking, INIT_SESSION) con interpolación suave (Lerp) para evitar saltos bruscos.
  - Consejos y tips rotativos en el footer.

- ⚡ **Máximo Rendimiento (0 Bloat):**
  - **Sin cursores virtuales duplicados:** Utiliza el cursor nativo de FiveM sin lag de renderizado.
  - **Sin contadores de FPS o herramientas innecesarias** que sobrecarguen la pantalla.
  - **Puro Vanilla HTML5 / CSS3 / JavaScript:** Sin React, Node.js ni compiladores necesarios; cualquier cliente o administrador puede configurarlo fácilmente abriendo config.js.

---

## ⌨️ Controles y Atajos de Teclado

| Tecla | Acción |
| :--- | :--- |
| **ESPACIO** | Pausar / Reanudar Música (o disparar en Space Defender) |
| **M** | Silenciar / Activar Sonido (Mute) |
| **H** | Alternar Modo Cine (Ocultar / Mostrar Interfaz completa) |
| **J** | Abrir / Cerrar Menú de Minijuegos |
| **ESC** | Salir del Modo Cine o cerrar cualquier ventana/modal |

---

## 📂 Estructura del Recurso

`	ext
vertex_loadingscreen/
├── fxmanifest.lua           <-- Manifiesto oficial de FiveM (cerulean)
├── README.md                <-- Documentación y guía de configuración
└── html/
    ├── index.html           <-- Estructura principal depurada y limpia
    ├── css/
    │   └── style.css        <-- Estilos Cyber-Chrome Titanium & Obsidian
    ├── js/
    │   ├── config.js        <-- Configuración editable (sociales, textos, etc.)
    │   └── app.js           <-- Motores de audio, minijuegos, eventos FiveM y persistencia
    └── assets/
        ├── bg.mp4           <-- Coloca aquí tu video de fondo en alta resolución
        ├── music.mp3        <-- Coloca aquí tu canción favorita en formato MP3
        └── logo.png         <-- Logotipo 3D oficial de Vertex Studio
`

---

## 🛠️ Instalación en Servidor FiveM

1. Coloca tu video de fondo en html/assets/bg.mp4.
2. Coloca tu pista de audio en html/assets/music.mp3 (o html/music.mp3).
3. Copia la carpeta ertex_loadingscreen dentro del directorio esources/ de tu servidor (ejemplo: esources/[scripts]/vertex_loadingscreen).
4. Abre tu archivo server.cfg y añade:
   `cfg
   ensure vertex_loadingscreen
   `
5. Inicia tu servidor FiveM.

---

## ⚙️ Personalización Rápida (html/js/config.js)

Puedes modificar fácilmente el comportamiento y la información abriendo html/js/config.js:
- **Config.audio**: Configura si arranca en autoplay, volumen inicial, nombre de la pista y artista.
- **Config.studio**: Nombre de marca, subtítulo, enlace de Discord y enlace de la Tienda Oficial.
- **Config.updates**: Anuncios y notas de novedades de la pestaña de noticias.
- **Config.rules**: Normativa del servidor por categorías.
- **Config.team**: Miembros del staff o equipo de desarrollo con sus roles y avatares.
- **Config.keybinds**: Guía visual de teclas del servidor.
- **Config.tips**: Consejos rotativos mostrados en la barra inferior.
- **Config.translations**: Textos en Español e Inglés.

---

## 🖥️ Previsualización en Navegador Web

1. Haz doble clic sobre html/index.html para abrirlo en cualquier navegador (Chrome, Edge, Brave, Firefox).
2. Se iniciará de forma automática una **simulación realista de carga (0% a 100%)**, permitiendo comprobar tu música music.mp3, el modo cine con la tecla H, el modo rendimiento y los minijuegos antes de colocarlo en el servidor.

---
*Desarrollado exclusivamente para Vertex Studio.*
