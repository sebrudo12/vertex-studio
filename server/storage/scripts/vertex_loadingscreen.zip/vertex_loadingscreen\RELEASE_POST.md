﻿# [RELEASE][STANDALONE] 🚀 Vertex Studio - Cyber-Chrome Loading Screen (0.00ms)

![FiveM](https://img.shields.io/badge/FiveM-Standalone-blue.svg)
![Framework](https://img.shields.io/badge/Framework-ESX%20%7C%20QBCore%20%7C%20Qbox%20%7C%20Standalone-success.svg)
![Performance](https://img.shields.io/badge/Resmon-0.00ms-brightgreen.svg)
![Design](https://img.shields.io/badge/Design-Cyber--Chrome%20Titanium-silver.svg)

¡Hola comunidad de Cfx.re! 

Desde **Vertex Studio** nos enorgullece presentar nuestra **Pantalla de Carga AAA**, diseñada con acabados en titanio cepillado, negro obsidiana, reflejos metálicos y un viewport completamente limpio para que tu cinemática o video de fondo luzca en su máximo esplendor.

Inspirada en las mejores interfaces del mercado (**Tuff**, **Wasabi** y **UM-Ronin**), pero optimizada al 100% sin librerías pesadas ni bloat innecesario.

---

## ✨ Características Principales

- 💎 **Estética Cyber-Chrome Glassmorphism:** Centro de la pantalla 100% despejado en Inicio para apreciar el video de fondo g.mp4 sin cuadros molestos.
- 🎵 **Música Local (music.mp3):** Cero dependencias de enlaces externos o CDNs caídos. Reproduce tu canción favorita en bucle continuo con ecualizador animado y control de volumen persistente.
- 🎬 **Modo Cine Inmersivo (Tecla H):** Con solo presionar la tecla H, la interfaz entera se desvanece suavemente para disfrutar del video y la música al 100%. Presiona H, ESC o haz clic para volver.
- 🔋 **Modo Rendimiento (Eco GPU):** Pensado para jugadores con PCs de bajos recursos o laptops. Pausa el video y apaga los filtros GPU pesados con un solo clic (guardado en LocalStorage).
- 🕹️ **Arcade Suite (3 Minijuegos Clásicos con Récords):**
  1. **Space Defender:** Arcade shooter espacial pilotando una nave en "V" de titanio.
  2. **Neon Snake:** El mítico juego de la serpiente en estilo neón cian.
  3. **FiveM Memory Hack:** Matriz 4x4 inspirada en los hackeos de robos de FiveM.
  - *Guarda automáticamente los puntajes más altos del jugador.*
- 👥 **Discord Live Widget:** Luz verde de pulso con contador de miembros en línea en tiempo real (🟢 1,420 En línea) y copiado automático de enlace al portapapeles.
- 🌐 **Soporte Bilingüe Integrado:** Selector instantáneo de Español (ES) e Inglés (EN).
- 📊 **Carga Real Sincronizada:** Escucha nativa de las 5 etapas del ciclo de vida NUI de FiveM (loadProgress, startDataFileEntries, performMapLoadFunction, initFunctionInvoking, INIT_SESSION) con interpolación suave (Lerp).
- ⚡ **0.00ms de Resmon & Sin Lag de Cursor:** Utiliza el cursor nativo de FiveM sin dobles punteros ni retraso de renderizado.
- 🛠️ **100% Vanilla (HTML5, CSS3, JS):** Sin React, Node.js ni compilaciones pesadas. Cualquier cliente puede abrir config.js y personalizarlo en 30 segundos.

---

## ⌨️ Controles de Teclado

| Tecla | Función |
| :--- | :--- |
| **ESPACIO** | Pausar / Reanudar Música (o disparar en Space Defender) |
| **M** | Silenciar / Activar Sonido (Mute) |
| **H** | Alternar Modo Cine (Ocultar / Mostrar Interfaz) |
| **J** | Abrir / Cerrar Menú de Minijuegos |
| **ESC** | Salir del Modo Cine o cerrar minijuegos |

---

## 🛠️ Instalación Rápida

1. Descarga y descomprime ertex_loadingscreen en la carpeta esources/ de tu servidor.
2. Coloca tu video de fondo en html/assets/bg.mp4.
3. Coloca tu canción en html/assets/music.mp3 (o html/music.mp3).
4. Abre html/js/config.js y añade tu Discord ID y redes sociales.
5. En tu server.cfg, añade:
   `cfg
   ensure vertex_loadingscreen
   `
6. ¡Inicia tu servidor y disfruta!

---

## 🔗 Enlaces y Soporte
- **Tienda Oficial Tebex:** [https://vertexstudio.tebex.io](https://vertexstudio.tebex.io)
- **Discord Oficial:** [https://discord.gg/vertexstudio](https://discord.gg/vertexstudio)
